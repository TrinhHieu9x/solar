﻿// Please see documentation at https://docs.microsoft.com/aspnet/core/client-side/bundling-and-minification
// for details on configuring this project to bundle and minify static web assets.

// Write your JavaScript code.

function setCookie(cname, cvalue, exdays) {
    const d = new Date();
    d.setTime(d.getTime() + (exdays * 24 * 60 * 60 * 1000));
    let expires = "expires=" + d.toUTCString();
    document.cookie = cname + "=" + cvalue + ";" + expires + ";path=/";
}

function getCookie(cname) {
    let name = cname + "=";
    let decodedCookie = decodeURIComponent(document.cookie);
    let ca = decodedCookie.split(';');
    for (let i = 0; i < ca.length; i++) {
        let c = ca[i];
        while (c.charAt(0) == ' ') {
            c = c.substring(1);
        }
        if (c.indexOf(name) == 0) {
            return c.substring(name.length, c.length);
        }
    }
    return "";
}


// For dynamic load string resources by reading language key from cookie.
// Default language is Vietnamese.
// Note: Load this file after load cookieUtils.js file

var language = getCookie('user_language');
console.log('[LanguageUtils] Load language from cookie: ' + language);
if (language == 'vi') {
    document.write("<scr" + "ipt src='/js/lang/lang.vi.js'>" + "</scr" + "ipt>");
}
else {
    document.write("<scr" + "ipt src='/js/lang/lang.en.js'>" + "</scr" + "ipt>");
}
