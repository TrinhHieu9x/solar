function closeCurrentPage() {
	window.opener = null; 
	window.open('', '_self'); 
	window.close();
}

/**
 * Check if email address valid...
 * @param email
 * @returns {Boolean}
 */
function checkEmail(email) {
	var emailRegExp = new RegExp("[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?");
	if (!emailRegExp.test(email) || email.indexOf('.') == -1 || email.indexOf('.') == (email.length - 1)) {
		return false;
	} else {
		return true;
	}
}

/**
 * Check if not negative integer...
 * @param int
 * @returns
 */
function checkInt(int) {
	return /^\d+$/.test(int);
}

function checkAllInt(int) {
	return /^-?\d+$/.test(int);
}

/**
 * Check if positive float...
 * @param float
 * @returns
 */
function checkFloat(float) {
	return new RegExp(/^(([0-9]+\.[0-9]*[1-9][0-9]*)|([0-9]*[1-9][0-9]*\.[0-9]+)|([0-9]*[1-9][0-9]*))$/).test(float);
}

/**
 * Check if text contain invalid character
 */
function containInvalidCharacter(text) {
	return text.indexOf('&') >= 0 || text.indexOf('\'') >= 0 || text.indexOf('"') >= 0 || text.indexOf('<') >= 0 || text.indexOf('>') >= 0 || text.indexOf(',') >= 0 || text.indexOf('\\') >= 0;
}

/**
 * Validate password...
 */
function validatePassword(password) {
	const requirements = {
		letters : /[A-Za-z]/.test(password),
		number: /[0-9]/.test(password)
	};

	return requirements;
}

/**
 * Check valid password...
 */
function isPasswordValid(password) {
	const reqs = validatePassword(password);
	return Object.values(reqs).every(valid => valid);
}

/**
 * fill with 0...
 */
function fillZeros(value, length) {
	var length = arguments[1] ? arguments[1] : 2;
	var valueText = new String(value);
	while(valueText.length < length) {
		valueText = '0' + valueText;
	}
	return valueText;
}

//Keep 2 decimal...
function toDecimal(x) {
    var f = parseFloat(x);
    if (isNaN(f)) {
        return;
    }
    f = round2(x);
    return f;
}

function round1(x) {
	return Math.round(x*10)/10;
}

function round2(x) {
	return Math.round(x*100)/100;
}

//Keep 2 decimal... fill with 00, like 2.00...
function toDecimal2(x) {
    var f = parseFloat(x);
    if (isNaN(f)) {
        return false;
    }
    var f = round2(x);
    var s = f.toString();
    var rs = s.indexOf('.');
    if (rs < 0) {
        rs = s.length;
        s += '.';
    }
    while (s.length <= rs + 2) {
        s += '0';
    }
    return s;
}

//金额相关同步变更文本框后提示信息
function onMoneyInput2AddOn(element) {
	var $addOn = $(element).next();
	var valueText = $(element).val();
	if(checkInt(valueText)) {
		$addOn.text((valueText / 100) + ' ' + $addOn.attr('unit'));
	} else {
		$addOn.text('');
	}
}

function rnd(seed) {
	seed = (seed*9301+49297) % 233280;
	return seed/(233280.0);
};

function setBtnLoading(btnId) {
	var $button = $(btnId);
	$button.attr('disabled', 'disabled');
	$button.data('originText', $button.text());
	$button.text($button.attr('data-loading-text'));
}

function resetBtn(btnId) {
	var $button = $(btnId);
	var originText = $button.data('originText');
	if(originText) {
		$button.text(originText);
	}
	$button.removeAttr('disabled');
}

function toHex2(data) {
	var dataText = data.toString(16);
	if(dataText.length < 2) {
		dataText = '0' + dataText;
	}
	return dataText.toUpperCase();
}

function deepCopyObjArray(srcArray) {
	var destArray = [];
	if(srcArray && srcArray.length > 0) {
		for(var i = 0; i < srcArray.length; i++) {
			destArray.push(Object.assign({}, srcArray[i]));
		}
	}
	return destArray;
}

function handleSecondText(second) {
	if(second >= 0) {
		return fillZeros(Math.floor(second / 60), 2) + ':' + fillZeros(second % 60, 2)
	}
	return '--';
}

function alertTitle(component) {
	var $component = $(component);
	if($component.is('[title]')) {
		alert($component.attr('title'))
	}
}