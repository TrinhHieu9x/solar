class Message {
    constructor() {
        // 消息队列
        this.messageQueue = [];
        // 设置默认值
        this.position = 'top';
        this.message = '';
        this.duration = 3000;
        this.body = document.getElementsByTagName('body')[0];
        this.id = 0;
    }

    removeMessageDom(messageDom, targetId) {
        const startIndex = this.messageQueue.findIndex(message => message.id === targetId);
        this.messageQueue.splice(startIndex, 1);
        this.updateMessageDom(startIndex);
        //增加移除动画
        messageDom.classList.add('ui-message-leave');
        setTimeout(() => {
            this.body.removeChild(messageDom);
        }, 400);
    }

    setOption(options) {
        if (typeof options !== "object") {
            options = {};
        }
        const messageDom = document.createElement('div');
        messageDom.classList.add('ui-message');
        messageDom.classList.add('alert');
        messageDom.classList.add('alert-danger');
        messageDom.classList.add('shadow');
        messageDom.setAttribute('role','alert');
        messageDom.classList.add('ui-message-leave');
        if (options.center === true) {
            messageDom.classList.add('ui-message-center');
        }
        const targetId = this.id;
        this.messageQueue.push({
            id: targetId,
            messageDom,
        });
        messageDom.innerText = options.message || this.message;
        this.setCurrentMessageDom();
        this.body.appendChild(messageDom);
        //增加新增动画
        setTimeout(() => {
            messageDom.classList.remove('ui-message-leave');
        }, 100);
        let i = null;

        const time = isNaN(Number(options.duration)) ? this.duration : Number(options.duration);
        // 如果duration为0则不需要setTimeout
        let timeId = -1;
        if (time !== 0) {
            timeId = setTimeout(() => {
                this.removeMessageDom(messageDom, targetId);
            }, time);
        }
        this.id++;
    }

    setCurrentMessageDom() {
        const index = this.messageQueue.length - 1;
        const targetDom = this.messageQueue[index].messageDom;
        targetDom.style.zIndex = `${99999 + index}`;
        targetDom.style.top = `${64 * index + 20}px`;
    }

    updateMessageDom(startIndex) {
        for (let i = startIndex; i < this.messageQueue.length; i++) {
            const messageDom = this.messageQueue[i].messageDom;
            messageDom.style.zIndex = `${99999 + i}`;
            // 暂不支持换行功能，换行后获取上一个元素的height和top来更新下一个元素的top
            messageDom.style.top = `${64 * i + 20}px`;
        }
    }
}